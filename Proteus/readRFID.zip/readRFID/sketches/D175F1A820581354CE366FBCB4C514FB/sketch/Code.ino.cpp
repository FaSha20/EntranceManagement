#include <Arduino.h>
#line 1 "F:\\فاطمه\\درسی\\ترم8\\CPS\\ca\\ca1\\RFID Security Lock\\Code\\Code.ino"
// include the library code:
#include <LiquidCrystal.h> //library for LCD 

// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(13, 12, 11, 10, 9, 8);

const int RedlED = 5;
const int GreenlED = 6;
const int DCMotor = 7;

int count = 0;
char c;
String id;

int wait = 5000;

#line 17 "F:\\فاطمه\\درسی\\ترم8\\CPS\\ca\\ca1\\RFID Security Lock\\Code\\Code.ino"
void setup();
#line 37 "F:\\فاطمه\\درسی\\ترم8\\CPS\\ca\\ca1\\RFID Security Lock\\Code\\Code.ino"
void loop();
#line 17 "F:\\فاطمه\\درسی\\ترم8\\CPS\\ca\\ca1\\RFID Security Lock\\Code\\Code.ino"
void setup()
{
  Serial.begin(9600);
  pinMode(RedlED, OUTPUT);
  pinMode(GreenlED, OUTPUT);
  pinMode(DCMotor, OUTPUT);

  Serial.println("Please scan your RFID Card");

  lcd.begin(20, 4); // set up the LCD's number of columns and rows:
  lcd.setCursor(0, 0);
  lcd.print("  THE BRIGHT LIGHT ");
  lcd.setCursor(0, 1);
  lcd.print(" RFID BASED LOCK SYS");
  lcd.setCursor(0, 2);
  lcd.print(" CARD:   ");
  lcd.setCursor(0, 3);
  lcd.print(" NAME:   ");
}

void loop()
{
  while (Serial.available() > 0)
  {
    c = Serial.read();
    count++;
    Serial.println(count);
    id += c;
    if (count == 9)
    {
      Serial.print(id);
      //break;

      if (id == "810199440")
      {
        Serial.println("Valid Card");
        lcd.setCursor(0, 2);
        lcd.print(" CARD: VALID   ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME: FATEMEH   ");
        digitalWrite(GreenlED, HIGH);
        // digitalWrite(DCMotor, HIGH);
        delay(1000);
        digitalWrite(GreenlED, LOW);
        delay(1000);
        // digitalWrite(DCMotor, LOW);
        lcd.setCursor(0, 2);
        lcd.print(" CARD:           ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME:           ");
      }

      else
      {
        Serial.println("Invalid Card");
        lcd.setCursor(0, 2);
        lcd.print(" CARD: INVALID   ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME: UNKNOWN     ");
        digitalWrite(RedlED, HIGH);
        delay(1000);
        digitalWrite(RedlED, LOW);
        lcd.setCursor(0, 2);
        lcd.print(" CARD:           ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME:           ");
      }
    }
  }
  count = 0;
  id = "";
  delay(500);
}

