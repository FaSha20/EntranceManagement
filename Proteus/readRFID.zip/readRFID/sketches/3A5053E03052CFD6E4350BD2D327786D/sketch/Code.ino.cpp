#include <Arduino.h>
#line 1 "C:\\Users\\Fateme\\OneDrive\\Desktop\\proteus\\Code\\Code.ino"
// include the library code:
#include <LiquidCrystal.h> //library for LCD 
#include <EtherCard.h>


static byte mymac[] = { 0x74, 0x69, 0x69, 0x2D, 0x30, 0x31 }; // Arduino's MAC address
byte Ethernet::buffer[500]; // Ethernet buffer size
// // Static IP configuration
static byte myip[] = { 192,168,2,2 }; // Arduino's static IP address
static byte gwip[] = { 192,168,2,1 }; // Gateway IP address

// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(13, 12, 11, 10, 9, 8);

const int RedlED = 5;
const int GreenlED = 6;
const int Buzzer = 7;

int count = 0;
char c;
String id;

int wait = 5000;

#line 25 "C:\\Users\\Fateme\\OneDrive\\Desktop\\proteus\\Code\\Code.ino"
void setup();
#line 37 "C:\\Users\\Fateme\\OneDrive\\Desktop\\proteus\\Code\\Code.ino"
void loop();
#line 25 "C:\\Users\\Fateme\\OneDrive\\Desktop\\proteus\\Code\\Code.ino"
void setup()
{
  Serial.begin(9600);
  pinMode(RedlED, OUTPUT);
  pinMode(GreenlED, OUTPUT);

  ether.begin(sizeof Ethernet::buffer, mymac, SS); // Initialize Ethernet with buffer size and MAC address
  ether.staticSetup(myip, gwip); // Set static IP and gateway
  
  
}

void loop()
{
  while (Serial.available() > 0)
  {
    c = Serial.read();
    count++;
    id += c;
    if (count == 12)
    {
      Serial.print(id);
      //break;

      if (id == "E280689401A9")
      {
        Serial.println("Valid Card");
        lcd.setCursor(0, 2);
        lcd.print(" CARD: VALID   ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME: ALTAF   ");
        digitalWrite(GreenlED, HIGH);
        delay(wait);
        digitalWrite(GreenlED, LOW);
        lcd.setCursor(0, 2);
        lcd.print(" CARD:           ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME:           ");
      }

      else
      {
        Serial.println("Invalid Card");
        lcd.setCursor(0, 2);
        lcd.print(" CARD: INVALID   ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME: UNKNOWN     ");
        digitalWrite(RedlED, HIGH);
        digitalWrite(Buzzer, HIGH);
        delay(500);
        digitalWrite(Buzzer, LOW);
        delay(4000);
        digitalWrite(RedlED, LOW);
        lcd.setCursor(0, 2);
        lcd.print(" CARD:           ");
        lcd.setCursor(0, 3);
        lcd.print(" NAME:           ");
      }
    }
  }
  count = 0;
  id = "";
  delay(500);

  char htmlResponse[250]; // Buffer for HTML response
  // Construct HTML response with potentiometer value
  sprintf(htmlResponse, "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n"
                        "<html>\r\n"
                        "<head>\r\n"
                        "<meta http-equiv='refresh' content='3'>\r\n"
                        "</head>\r\n"
                        "<body>\r\n"
                        "Potentiometer value: %s\r\n"
                        "</body>\r\n"
                        "</html>\r\n", id_input);

  word pos = ether.packetLoop(ether.packetReceive());
  if (pos) {
    char *data = (char *)Ethernet::buffer + pos; // Pointer to packet data
    // Copy HTML response to Ethernet buffer
    memcpy(ether.tcpOffset(), htmlResponse, strlen(htmlResponse));
    // Send HTTP server reply with HTML response length
    ether.httpServerReply(strlen(htmlResponse));
  }
  
}

