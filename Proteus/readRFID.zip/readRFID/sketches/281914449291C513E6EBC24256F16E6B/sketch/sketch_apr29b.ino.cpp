#include <Arduino.h>
#line 1 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-14852-1g36mz2.1wim\\sketch_apr29b\\sketch_apr29b.ino"
#include <SPI.h>
#include <Ethernet.h>

// Enter your network settings
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED }; // MAC address
IPAddress ip(192, 168, 2, 2); // IP address of Arduino
IPAddress server(192, 168, 2, 1); // IP address of the server
EthernetClient client;

// LED pins
const int ledPinON = 5; // LED to turn ON
const int ledPinOFF = 4; // LED to turn OFF

#line 14 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-14852-1g36mz2.1wim\\sketch_apr29b\\sketch_apr29b.ino"
void setup();
#line 32 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-14852-1g36mz2.1wim\\sketch_apr29b\\sketch_apr29b.ino"
void loop();
#line 39 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-14852-1g36mz2.1wim\\sketch_apr29b\\sketch_apr29b.ino"
void sendToServer(String command);
#line 14 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-14852-1g36mz2.1wim\\sketch_apr29b\\sketch_apr29b.ino"
void setup() {
  Serial.begin(9600);
  pinMode(ledPinON, OUTPUT);
  pinMode(ledPinOFF, OUTPUT);
  
  // Start Ethernet connection
  if (Ethernet.begin(mac) == 0) {
    Serial.println("Failed to configure Ethernet using DHCP");
    // Set a static IP address if DHCP fails
    Ethernet.begin(mac, ip);
  }

  // Wait for Ethernet to initialize
  delay(1000);
  
  Serial.println("Enter command to send to server (ON or OFF):");
}

void loop() {
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    sendToServer(command);
  }
}

void sendToServer(String command) {
  // Connect to server
  if (client.connect(server, 80)) {
    Serial.println("Connected to server");

    // Send data to server
    client.print("GET /?command=");
    client.print(command);
    client.println(" HTTP/1.1");
    client.print("Host: ");
    client.println(server);
    client.println("Connection: close");
    client.println();

    // Read server response
    String response = "";
    while (client.connected()) {
      if (client.available()) {
        char c = client.read();
        response += c;
      }
    }
    Serial.println("Response received: " + response);

    // Check response and control LEDs
    if (response.indexOf("ON") != -1) {
      digitalWrite(ledPinON, HIGH);
      digitalWrite(ledPinOFF, LOW);
    } else if (response.indexOf("OFF") != -1) {
      digitalWrite(ledPinON, LOW);
      digitalWrite(ledPinOFF, HIGH);
    }

    // Disconnect from server
    client.stop();
  } else {
    Serial.println("Connection failed");
  }
}

