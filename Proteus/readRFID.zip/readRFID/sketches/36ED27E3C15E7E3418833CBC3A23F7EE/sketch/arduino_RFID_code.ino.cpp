#include <Arduino.h>
#line 1 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
#include <EtherCard.h>

#define REQUEST_RATE 5000 // milliseconds

// ethernet interface mac address
static byte mymac[] = { 0x74,0x69,0x69,0x2D,0x30,0x31 };
// ethernet interface ip address
static byte myip[] = { 192,168,2,2 };
// gateway ip address
static byte gwip[] = { 192,168,2,1 };
// remote website ip address and port
static byte hisip[] = { 192,168,2,1 };
// remote website name
const char website[] PROGMEM = "192.168.2.1";

const int RedlED = 5;
const int GreenlED = 4;
int count = 0;
char c;
String id;
char id_input[50] = "hello";

byte Ethernet::buffer[700];   // a very small tcp/ip buffer is enough here
static long timer;

#line 26 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
void sendHttpResponse(char* id);
#line 50 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
char * read_RFID_from_terminal();
#line 71 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
void setup();
#line 95 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
void loop();
#line 26 "C:\\Users\\Fateme\\OneDrive\\Desktop\\EntranceManagement\\arduino_RFID_code\\arduino_RFID_code.ino"
void sendHttpResponse(char* id) {
  char htmlResponse[400];
  sprintf(htmlResponse,
          "HTTP/1.1 200 OK\r\n"
          "Content-Type: text/html\r\n"
          "Connection: close\r\n"
          "Authentication: %s \r\n"
          "\r\n"
          "<!DOCTYPE html>\r\n"
          "<html>\r\n"
          "<head>\r\n"
          "<title>Entrance Management</title>\r\n"
          "</head>\r\n"
          "<body>\r\n"
          "<h1>Welcome to Entrance Management Platform!</h1>\r\n"
          "<p><a href=\"/led/on\">Turn On</a> | <a href=\"/led/off\">Turn Off</a></p>\r\n"
          "</body>\r\n"
          "</html>\r\n",
          id);
  // Send response
  memcpy(ether.tcpOffset(), htmlResponse, strlen(htmlResponse));
  ether.httpServerReply(strlen(htmlResponse));
}

char* read_RFID_from_terminal(){
  int count = 0;
  char c;
  String id;
  char input[50];
  while (Serial.available() > 0){
      c = Serial.read();
      count++;
      id += c;
      if (count == 9 ){
        // if(id == "810199440"){
        //    digitalWrite(GreenlED, HIGH);
        //    delay(100);
        //    digitalWrite(GreenlED, LOW);
        // }
        id.toCharArray(input, 50);
        return input;
      }
  }  
}

void setup () {
  // Serial.begin(57600);
  Serial.begin(9600);
  Serial.println("\n[getStaticIP]");

  pinMode(RedlED, OUTPUT);
  pinMode(GreenlED, OUTPUT);

  // Change 'SS' to your Slave Select pin, if you arn't using the default pin
  if (ether.begin(sizeof Ethernet::buffer, mymac, SS) == 0)
    Serial.println( "Failed to access Ethernet controller");

  ether.staticSetup(myip, gwip);

  ether.copyIp(ether.hisip, hisip);
  ether.printIp("Server: ", ether.hisip);

  while (ether.clientWaitingGw())
    ether.packetLoop(ether.packetReceive());
  Serial.println("Gateway found");

  timer = - REQUEST_RATE; // start timing out right away
}

void loop () {
  // char* id = read_RFID_from_terminal();
  
  while (Serial.available() > 0){
      c = Serial.read();
      count++;
      id += c;
      if (count == 9 ){
        // if(id == "810199440"){
        //    digitalWrite(GreenlED, HIGH);
        // }else{
        //   digitalWrite(RedlED, HIGH);
        // }
        id.toCharArray(id_input, 50);
        break;
      }
  }  
  
  delay(500);

  word pos = ether.packetLoop(ether.packetReceive());
  if (pos) {
    // Extract data from Ethernet buffer
    char *data = (char *)Ethernet::buffer + pos;
    sendHttpResponse(id_input);
  }   

}

