#include <Arduino.h>
#line 1 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-15232-vmplxk.02uik\\sketch_apr29a\\sketch_apr29a.ino"
// const int RedlED = 4;
// const int GreenlED = 5;

// void setup() {
//   // put your setup code here, to run once:
//   Serial.begin(9600);
//   pinMode(RedlED, OUTPUT);
//   pinMode(GreenlED, OUTPUT);
// }

// void loop() {
//   // put your main code here, to run repeatedly:

//   int charsRead;
//   char input[10];
//   int incomingByte = 0;

//  while (Serial.available()) {
//     incomingByte = Serial.read();
    
//     if(incomingByte > 4){
//       digitalWrite(RedlED, HIGH);
//     }
//     else{
//       digitalWrite(GreenlED, HIGH);
//     }
//   }
// }


int incomingByte = 0; // for incoming serial data

#line 33 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-15232-vmplxk.02uik\\sketch_apr29a\\sketch_apr29a.ino"
void setup();
#line 37 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-15232-vmplxk.02uik\\sketch_apr29a\\sketch_apr29a.ino"
void loop();
#line 33 "C:\\Users\\Fateme\\AppData\\Local\\Temp\\.arduinoIDE-unsaved2024329-15232-vmplxk.02uik\\sketch_apr29a\\sketch_apr29a.ino"
void setup() {
  Serial.begin(9600); // opens serial port, sets data rate to 9600 bps
}

void loop() {
  Serial.print("I received: ");
  // send data only when you receive data:
  // if (Serial.available() > 0) {
  //   // read the incoming byte:
  //   incomingByte = Serial.read();

  //   // say what you got:
  //   Serial.print("I received: ");
  //   Serial.println(incomingByte, DEC);
  // }
}
