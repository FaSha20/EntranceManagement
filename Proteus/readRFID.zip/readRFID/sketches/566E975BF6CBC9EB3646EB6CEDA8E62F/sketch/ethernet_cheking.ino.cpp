#include <Arduino.h>
#line 1 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
// #include <EtherCard.h>



// const int RedlED = 5;
// const int GreenlED = 4;

// // ethernet interface mac address
// static byte mymac[] = { 0x74,0x69,0x69,0x2D,0x30,0x31 };
// // ethernet interface ip address
// static byte myip[] = { 192,168,2,2 };
// // gateway ip address
// static byte gwip[] = { 192,168,2,1 };
// // remote website ip address and port
// static byte hisip[] = { 192,168,2,1 };
// // remote website name
// const char website[] PROGMEM = "192.168.2.1";

// byte Ethernet::buffer[300];   // a very small tcp/ip buffer is enough here

// void sendHttpResponse(char* id) {
//   char htmlResponse[400];
//   sprintf(htmlResponse,
//           "HTTP/1.1 200 OK\r\n"
//           "Content-Type: text/html\r\n"
//           "Connection: close\r\n"
//           "\r\n"
//           "<!DOCTYPE html>\r\n"
//           "<html>\r\n"
//           "<head>\r\n"
//           "<title>Entrance Management</title>\r\n"
//           "</head>\r\n"
//           "<body>\r\n"
//           "<h1>Welcome to Entrance Management Platform!</h1>\r\n"
//           "<p>ID is %s</p>\r\n"
//           "<p><a href=\"/led/on\">Turn On</a> | <a href=\"/led/off\">Turn Off</a></p>\r\n"
//           "</body>\r\n"
//           "</html>\r\n",
//           id);
//   // Send response
//   memcpy(ether.tcpOffset(), htmlResponse, strlen(htmlResponse));
//   ether.httpServerReply(strlen(htmlResponse));
// }

// char* read_RFID_from_terminal(){
//   int count = 0;
//   char c;
//   String id;
//   char input[50];
//   while (Serial.available() > 0){
//       c = Serial.read();
//       count++;
//       id += c;
//       if (count == 9 ){
//         if(id == "810199440"){
//            digitalWrite(GreenlED, HIGH);
//            delay(100);
//            digitalWrite(GreenlED, LOW);
//         }
//         id.toCharArray(input, 50);
//         return input;
//       }
//   }  
//   count = 0;
//   id = "";
// }

// void setup () {
//   Serial.begin(57600);
//   // Serial.begin(9600);
  
//   pinMode(RedlED, OUTPUT);
//   pinMode(GreenlED, OUTPUT);

//   // Change 'SS' to your Slave Select pin, if you arn't using the default pin
//   if (ether.begin(sizeof Ethernet::buffer, mymac, SS) == 0)
//     Serial.println( "Failed to access Ethernet controller");

//   ether.staticSetup(myip, gwip);

//   ether.copyIp(ether.hisip, hisip);
//   ether.printIp("Server: ", ether.hisip);

//   while (ether.clientWaitingGw())
//     ether.packetLoop(ether.packetReceive());
//   Serial.println("Gateway found");

// }

// void loop () {

//   char* id_input = read_RFID_from_terminal();
//   delay(1000);

//   word pos = ether.packetLoop(ether.packetReceive());
//   if (pos) {
//     // Extract data from Ethernet buffer
//     char *data = (char *)Ethernet::buffer + pos;
    
//     sendHttpResponse(id_input);
    
//   }  
// }


#include <EtherCard.h>

#define REQUEST_RATE 5000 // milliseconds

// ethernet interface mac address
static byte mymac[] = { 0x74,0x69,0x69,0x2D,0x30,0x31 };
// ethernet interface ip address
static byte myip[] = { 192,168,2,2 };
// gateway ip address
static byte gwip[] = { 192,168,2,1 };
// remote website ip address and port
static byte hisip[] = { 192,168,2,1 };
// remote website name
const char website[] PROGMEM = "192.168.2.1";

const int RedlED = 5;
const int GreenlED = 4;

byte Ethernet::buffer[700];   // a very small tcp/ip buffer is enough here
static long timer;

#line 127 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
void sendHttpResponse(char* id);
#line 151 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
char * read_RFID_from_terminal();
#line 172 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
char * read_from_device();
#line 180 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
static void my_result_cb(byte status, word off, word len);
#line 187 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
void setup();
#line 215 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
void loop();
#line 127 "C:\\Users\\Fateme\\OneDrive\\Documents\\Arduino\\ethernet_cheking\\ethernet_cheking.ino"
void sendHttpResponse(char* id) {
  char htmlResponse[400];
  sprintf(htmlResponse,
          "HTTP/1.1 200 OK\r\n"
          "Content-Type: text/html\r\n"
          "Connection: close\r\n"
          "Authentication: %s \r\n"
          "\r\n"
          "<!DOCTYPE html>\r\n"
          "<html>\r\n"
          "<head>\r\n"
          "<title>Entrance Management</title>\r\n"
          "</head>\r\n"
          "<body>\r\n"
          "<h1>Welcome to Entrance Management Platform!</h1>\r\n"
          "<p><a href=\"/led/on\">Turn On</a> | <a href=\"/led/off\">Turn Off</a></p>\r\n"
          "</body>\r\n"
          "</html>\r\n",
          id);
  // Send response
  memcpy(ether.tcpOffset(), htmlResponse, strlen(htmlResponse));
  ether.httpServerReply(strlen(htmlResponse));
}

char* read_RFID_from_terminal(){
  int count = 0;
  char c;
  String id;
  char input[50];
  while (Serial.available() > 0){
      c = Serial.read();
      count++;
      id += c;
      if (count == 9 ){
        // if(id == "810199440"){
        //    digitalWrite(GreenlED, HIGH);
        //    delay(100);
        //    digitalWrite(GreenlED, LOW);
        // }
        id.toCharArray(input, 50);
        return input;
      }
  }  
}

char* read_from_device(){
  int potValue = analogRead(A0); // Read analog value from potentiometer connected to A0
  char potString[6]; // Buffer for converting potentiometer value to string
  itoa(potValue, potString, 10);
  return potString;
}

// called when the client request is complete
static void my_result_cb (byte status, word off, word len) {
  Serial.print("<<< reply ");
  Serial.print(millis() - timer);
  Serial.println(" ms");
  Serial.println((const char*) Ethernet::buffer + off);
}

void setup () {
  // Serial.begin(57600);
  Serial.begin(9600);
  Serial.println("\n[getStaticIP]");

  pinMode(RedlED, OUTPUT);
  pinMode(GreenlED, OUTPUT);

  // Change 'SS' to your Slave Select pin, if you arn't using the default pin
  if (ether.begin(sizeof Ethernet::buffer, mymac, SS) == 0)
    Serial.println( "Failed to access Ethernet controller");

  ether.staticSetup(myip, gwip);

  ether.copyIp(ether.hisip, hisip);
  ether.printIp("Server: ", ether.hisip);

  while (ether.clientWaitingGw())
    ether.packetLoop(ether.packetReceive());
  Serial.println("Gateway found");

  timer = - REQUEST_RATE; // start timing out right away
}
int count = 0;
char c;
String id;
char id_input[50] = "hello";

void loop () {
  // char* id = read_RFID_from_terminal();
  // char* id = read_RFID_from_terminal();
  //char* id = "hiii";

  
  while (Serial.available() > 0){
      c = Serial.read();
      count++;
      id += c;
      if (count == 9 ){
        if(id == "810199440"){
           digitalWrite(GreenlED, HIGH);
        }else{
          digitalWrite(RedlED, HIGH);
        }
        id.toCharArray(id_input, 50);
        break;
      }
  }  
  
  delay(500);

  word pos = ether.packetLoop(ether.packetReceive());
  if (pos) {
    // Extract data from Ethernet buffer
    char *data = (char *)Ethernet::buffer + pos;
    
    sendHttpResponse(id_input);
    
  }   

}


// void loop() {
//   int potValue = analogRead(A0); // Read analog value from potentiometer connected to A0
//   char potString[6]; // Buffer for converting potentiometer value to string
//   itoa(potValue, potString, 10); // Convert potentiometer value to string

//   char htmlResponse[250]; // Buffer for HTML response
//   // Construct HTML response with potentiometer value
//   sprintf(htmlResponse, "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n"
//                         "<html>\r\n"
//                         "<head>\r\n"
//                         "<meta http-equiv='refresh' content='3'>\r\n"
//                         "</head>\r\n"
//                         "<body>\r\n"
//                         "Potentiometer value: %s\r\n"
//                         "</body>\r\n"
//                         "</html>\r\n", potString);

//   // Check for incoming packets
//   word pos = ether.packetLoop(ether.packetReceive());
//   if (pos) {
//     char *data = (char *)Ethernet::buffer + pos; // Pointer to packet data
//     // Copy HTML response to Ethernet buffer
//     memcpy(ether.tcpOffset(), htmlResponse, strlen(htmlResponse));
//     // Send HTTP server reply with HTML response length
//     ether.httpServerReply(strlen(htmlResponse));
//   }
// }
  
  
  // if (millis() > timer + REQUEST_RATE) {
  //   timer = millis();
  //   Serial.println("\n>>> REQ");
  //   ether.browseUrl(PSTR("/hello/"), "", website, my_result_cb);
  // }

