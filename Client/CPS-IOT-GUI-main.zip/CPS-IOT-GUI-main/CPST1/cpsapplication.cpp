#include <QLineEdit>
#include <QDebug>

#include "cpsapplication.h"
#include "sock.h"

namespace CPS {

Application::Application(QObject *parent)
    : QObject{parent},
    _window(new MainWindow),
    _history(new HistoryWindow),
    _sockInstance(new Sock)
{
    setWindowsThemeToDark<MainWindow>(*_window);
    QObject::connect(_window, &MainWindow::historyuBtnClicked, this, &Application::showHistoryWindow);
    QObject::connect(_window, &MainWindow::connectBtnClicked, _sockInstance, &Sock::askserver);
    QObject::connect(_sockInstance, &Sock::newUser, _window, &MainWindow::showUserDetails);
    // QObject::connect(&YourSocketClassInstance, &YourSocketClass::connectionChanged, &window, &MainWindow::changeRightPanelEnabled);
}

void Application::callServer() {
    // QLineEdit *_addressInput = new QLineEdit(this->_window->_addressInput);
    // QString addressText = _addressInput->text();

    // QLineEdit *usr = new QLineEdit(this->_window->_usernameInput);
    // QString username = _addressInput->text();

    // QLineEdit *pass = new QLineEdit(this->_window->_passwordInput);
    // QString password = _addressInput->text();

    // qDebug() << addressText;
    // qDebug() << username;
    // qDebug() << password;
}

Application::~Application()
{
    delete this->_window;
    delete this->_history;

    //TODO:
    delete this->_sockInstance;
}

void Application::show()
{
    this->_window->show();
}

void Application::showHistoryWindow()
{
    setWindowsThemeToDark<HistoryWindow>(*_history);

    // TODO:
    /*
         * fetch data from server and show it in history window.
         * your data must be in QJsonArray format.
         * something like this:
         *
         * {
             data:  [
                 *     {
                 *          username: string,
                 *          date: string,
                 *          time: string,
                 *     },
                 *
                 *     {
                 *          username: string,
                 *          date: string,
                 *          time: string,
                 *     }
             * ]
         * }
         *
         *  below is an example of how to create a QJsonArray from QVariantList: (beginer level)
         *  please erase this horrible example and implement your own logic.
         *  you must fetch a json from server
         *
         * */

        // QString response = "{
        //     data:  [
        //             {
        //                 username: "1",
        //                 date: "1",
        //                 time: "1",
        //             },
                 
        //             {
        //                 username: "@",
        //                 date: "2",
        //                 time: "2",
        //             }
        //     ]
        // }"

    QJsonObject obj1;
    QJsonObject obj2;
    QJsonObject obj3;

    obj1["username"] = "1234567890";
    obj1["date"] = "12/12/2024";
    obj1["time"] = "10:00";

    obj2["username"] = "0987654321";
    obj2["date"] = "03/28/2024";
    obj2["time"] = "12:00";

    obj3["username"] = "5432167890";
    obj3["date"] = "09/08/2024";
    obj3["time"] = "14:00";

    QVariantList list;
    list.append(obj1);
    list.append(obj2);
    list.append(obj3);

    QJsonArray data = QJsonArray::fromVariantList(list);

    _history->show(data);
}

} // end of CPS
