#ifndef SOCK_H
#define SOCK_H
#include <QObject>
#include <QtWebSockets/QWebSocketServer>
#include <QtWebSockets/QWebSocket>

namespace CPS {

class Sock : public QObject
{
    Q_OBJECT

public:
    Sock(QObject *parent = nullptr);
    ~Sock();
    void sendMessageToServer(QString, QString);
    QWebSocketServer *server;
    QWebSocket *client;
Q_SIGNALS:
    void newUser(QString, QString, QString);
public Q_SLOTS:
    void askserver(QString, QString, QString);
    void processTextMessage(QString);
private: // methods
    void connectserver(QString);
// private: // members
};

}

#endif // SOCK_H
