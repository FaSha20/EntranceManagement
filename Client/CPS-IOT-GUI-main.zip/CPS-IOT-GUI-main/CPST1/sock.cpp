
#include <QLineEdit>
#include "sock.h"
#include <QDateTime>

namespace CPS {

Sock::Sock(QObject *parent) {
    connect(this, &QObject::destroyed, [this]() {qDebug() << "sock is destroyed";});
}

Sock::~Sock() {
    if (client) {
        delete client;
    }
}

void Sock::processTextMessage(QString msg) {
    qDebug() << "Message received from client:" << msg;
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QDate currentDate = currentDateTime.date();
    QString datestr = currentDate.toString("dd.MM.yyyy");

    currentDateTime = QDateTime::currentDateTime();
    QTime currentTime = currentDateTime.time();
    QString timestr = currentTime.toString("hh:mm:ss AP");

    if (msg != "") {
        qDebug() << "the user is added!";
        emit newUser(msg, datestr, timestr);
    }
}

void Sock::connectserver(QString url) {
    client = new QWebSocket();
    client->open(url);
}

void Sock::sendMessageToServer(QString name, QString pass) {
    QString message = name+":"+pass;
    if (client) {
        client->sendTextMessage(message);
        qDebug() << "Message sent to server:" << message;
    } else {
        qDebug() << "Failed to send message: client not connected or invalid.";
    }
}

void Sock::askserver(QString addr, QString name, QString pass) {
    // QString url = "ws://localhost:12345";
    QString url = addr;
    client = new QWebSocket();
    client->open(url);
    connect(client, &QWebSocket::connected, this, [=]() {sendMessageToServer(name, pass);} );
    connect(client, &QWebSocket::textMessageReceived, this, &Sock::processTextMessage);

    qDebug() << "client connected";
}

}
